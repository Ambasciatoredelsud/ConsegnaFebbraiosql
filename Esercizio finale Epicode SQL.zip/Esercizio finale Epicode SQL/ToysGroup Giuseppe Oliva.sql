create schema ToysGroup;

create table product
(
product_id int primary key not null,
product_name varchar(50),
product_category varchar(50),
product_price double
);

insert into product (product_id, product_name,product_category,product_price) values
(01, 'Lego bimbi', 'Costruzioni',15.90),
(02,  'Lego Adulti', 'Costruzioni',29.90),
(03, 'Pista Imola', 'Piste',69.90),
(04, 'Jaguar Diabolik', 'Macchinine',29.90),
(05, 'Ferrovie del Sud Est', 'Trenini',79.90),
(06,  'Sirio il Dragone', 'Personaggi',19.90),
(07,  'Andromeda la Notte', 'Personaggi',18.90),
(08,  'Allegro Chirurgo', 'Scienza e Gioco',29.90),
(09,  'Puzzle', 'Educativi',22.90),
(10, 'Acquerelli', 'Immaginazione', 19.90);

select * from product;

create table Sales
(
sales_id int primary key not null,
sales_date date,
region_id varchar (25),
product_id integer not null,
product_price double,
product_quantity integer,
total  double
);

insert into Sales (sales_id,sales_date,region_id,product_id,product_price,product_quantity,total)
values
(001,'2024-01-10', 1, 01, 15.90, 2897,459823),				
(002, '2024-01-05', 2, 02, 29.90, 3645,125746),				
(003, '2024-01-27', 3, 03, 69.90, 4786,139856),				
(004, '2024-01-14', 4, 04, 29.90, 1367,459876),				
(005, '2024-01-29', 5, 05, 79.90, 3845,149875),				
(006, '2024-02-03', 6, 06, 19.90, 1578,16853),				
(007, '2024-01-09', 1, 07, 18.90, 8732,798632),				
(008, '2024-02-08', 2, 08, 29.90, 7921,213589),				
(009, '2024-01-09', 3, 09, 22.90, 4587,732156),				
(010, '2023-12-10', 4, 10, 19.90, 1235,982314),				
(011, '2023-12-08', 5, 01, 15.90, 7845,96220),				
(012, '2023-12-12', 6, 02, 29.90, 1269,27386),				
(013, '2023-12-16', 6, 03, 69.90, 3287,412740),				
(014, '2023-12-07', 5, 04, 29.90, 7469,58963),				
(015, '2024-12-18', 4, 05, 79.90, 1276,49732),				
(016, '2023-12-21', 3, 06, 19.90, 9841,19476),				
(017, '2023-12-20', 2, 07, 18.90, 1282,76281),				
(018, '2023-12-24', 1, 08, 29.90, 1681,613249),				
(019, '2023-12-23', 6, 09, 22.90, 2991,71132),				
(020, '2023-12-17', 4, 10, 19.90, 3892,4561);			


select * from sales;

create table region
(
id_region smallint primary key not null,
region_name varchar(50)
);

insert into Region (id_region, region_name)
values
(1, 'Puglia'),
(2, 'Sicilia'),
(3, 'Campania'),
(4, 'Abruzzo'),
(5, 'Calabria'),
(6, 'Basilicata');

select * from region;


-- es. 1 Verificare che i campi definiti come PK siano univoci

select case when count(distinct sales_id) = count(sales_id)
then "unique" else "not unique" end
from sales;

select case when count(distinct id_region)= count(id_region)
then 'unique' else 'not unique' end
from region;

select case when count(distinct product_id)= count(product_id)
then 'unique' else 'not unique' end
from product;

-- es. 1 sostituire nome colonna id_region con region_id

alter table region change id_region region_id int;

select * from region;

-- es. 2 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT 
	product_name,YEAR(sales_date) AS sales_year, SUM(total)
FROM
    sales
        JOIN
    product ON sales.product_id = product.product_id
GROUP BY product_name , sales_year, total
Order by sales_year, total asc;

-- es. 3 Esporre il fatturato totale per stato per anno.
-- Ordina il risultato per data e per fatturato decrescente

select 
    region_name,
    year(sales_date) as year_sales,
    sum(total) as total
from sales 
join region on sales.region_id = region.region_id
group by region.region_name, year_sales
order by year_sales, total desc;

-- es. 4 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

select product_category, sum(product_quantity) as tot_qtà, year(sales_date) As sales_year
from product
join sales on product.product_id= sales.product_id
Group by product_category, sales_year
Order by sales_year, tot_qtà desc;

-- es. 5 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
-- Proporre due approcci risolutivi differenti. 

 -- 1° tentativo:
 
 update sales set product_quantity= 0 where sales_id=20;
 
 select sales_id, product_id, product_quantity
from sales
where product_quantity =0;
 

-- 2° tentativo

select
product.product_id,
product. product_name,
product_quantity,
sales.product_id,
sales.sales_id,
sales.sales_date
from product
left join sales on product.product_id = sales.product_id
where product_quantity = 0;


-- es. 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select distinct
	product.product_id,
    product.product_name,
    sales.sales_date
from product
left join sales on product.product_id = sales.product_id
where sales.sales_date = (
        select max(sales_date)
        from sales
        where product_id = product.product_id);
        
-- FINAL
